# Dashboard Financeiro Nóga 2026

## Publicar na Vercel usando GitHub

1. Crie um repositório no GitHub e envie o conteúdo desta pasta para ele.
2. Na Vercel, clique em **Add New → Project** e importe esse repositório.
3. Em **Framework Preset**, selecione **Other**.
4. Deixe **Build Command** vazio e **Output Directory** como `public`.
5. Clique em **Deploy**.

O dashboard está em `public/index.html`, que será servido como página inicial.

Observação: as alterações no dashboard são salvas localmente no navegador. Para compartilhar e sincronizar edições entre diferentes pessoas/dispositivos, será necessário adicionar um banco de dados.
